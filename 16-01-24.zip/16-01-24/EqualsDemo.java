class EqualsDemo{
	public static void main(String args[]){
		String s1="Bmsce";
		String s2="Bmsce";
		String s3="College";
		String s4="BMSCE";
		System.out.println(s1+" equals "+s2+" -> "+s1.equals(s2));
		System.out.println(s1+" equals "+s3+" -> "+s1.equals(s3));
		System.out.println(s1+" equals "+s4+" -> "+s1.equals(s4));
		System.out.println(s1+" equalsIgnoreCase "+s4+" -> "+s1.equalsIgnoreCase(s4));
	}
}