 class Concat{
    public static void main(String[] args) {
        String s1 = "hello";
        String s2 = "world";
        String result = s1.concat(s2);
        System.out.println("s1: " + s1);
        System.out.println("s2: " + s2);
        System.out.println("Concatenated Result: " + result);
    }
}
