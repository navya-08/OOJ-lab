class Replace {
    public static void main(String[] args) {
        String originalString = "Welcome to Bmsce College";
        String replacedString = originalString.replace("College", "Commege");
        System.out.println("Original String: '" + originalString + "'");
        System.out.println("Replaced String: '" + replacedString + "'");
    }
}
