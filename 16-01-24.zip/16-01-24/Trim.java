 class Trim {
    public static void main(String[] args) {
        String originalString = " Hello Friends ";
        String trimmedString = originalString.trim();
        System.out.println("Original String: '" + originalString + "'");
        System.out.println("Trimmed String: '" + trimmedString + "'");
    }
}
